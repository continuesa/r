// let path = '/src/config/logos';
let path = '/static/logos';
window.configGlobals = {
    name: "configGlobals----中文",
    logo: `${path}/logo.svg`
}