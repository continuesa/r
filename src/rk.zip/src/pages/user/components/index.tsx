import { memo } from 'react';
import styles from './index.module.scss';

const Index = () => {
    return (
        <div className={styles.logo}>
            <h1>用户首页</h1>
        </div>
    );
};

export default Index;
