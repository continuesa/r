# models 管理状态和方法
```html
    - models
        |- actions  动作方法
        |- hooks    钩子函数
        |- slices   初始值数据 
        |- store    仓库管理中心
        |- types    常量类型
        
```
