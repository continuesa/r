import { rootSlices } from '../slices';
export const actions = {
    ...rootSlices.counterSlice.actions,
};

