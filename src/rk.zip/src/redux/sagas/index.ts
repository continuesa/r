import createSagaMiddleware from 'redux-saga'
import { call, put, takeEvery, takeLatest } from 'redux-saga/effects';
// Worker saga will be fired on USER_FETCH_REQUESTED actions
import * as Api from '../../services';
function* fetchUser() {
    /*try {
        const user = yield call(Api.fetchUser, action.payload.userId);
        yield put({type: "USER_FETCH_SUCCEEDED", user: user});
    } catch (e) {
        yield put({type: "USER_FETCH_FAILED", message: e.message});
    }*/
}

// Starts fetchUser on each dispatched USER_FETCH_REQUESTED action
// Allows concurrent fetches of user
export default function* rootSaga() {
    yield takeEvery("USER_FETCH_REQUESTED", fetchUser);
}