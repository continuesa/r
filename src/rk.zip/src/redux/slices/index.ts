import { counterSlice } from './counter';

export const rootSlices = {
    counterSlice,
}