export const fetchUserApi = async () => {

}