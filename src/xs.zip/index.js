const EventEmitter = require('events');

// REM根元素的初始化设置
/*export const initRootRemSize = ({cab}) => {
    let designSize = 1920;
    const html = document.documentElement;
    let cw = html.clientWidth;
    if (cw <= 750) {
        designSize = 414;
    }

    if (cw > 750 && cw <= 1440) {
        designSize = 1440;
    }

    if (cw > 1440 && cw <= 2560) {
        // designSize = 2560;
        designSize = cw;
    }

    const w = cw;
    const remSize = (w / designSize) * 100;
    html.style.fontSize = `${remSize}px`;
    cab(w);
};*/


// REM根元素的初始化设置
export const initRootRemSize = ({ cab }) => {
    const flag = false;
    function initResize() {
        let designSize = 1920;
        const html = document.documentElement;
       
        // let cw = html.clientWidth;
        let cw = html.getBoundingClientRect().width;
        
        if (cw <= 750) {
            designSize = 750;
        }

        if (cw > 750 && cw <= 1440) {
            designSize = 1440;
        }

        if (cw > 1440 && cw <= 2560) {
            // designSize = 2560;
            designSize = cw;
        }

        const w = cw;

        cab(w);

        if(flag){
            const remSize = (w / designSize) * 100;
            html.style.fontSize = `${remSize}px`;
        }else{
            // 如果小于或者等于 750 的设计图，就设置根元素字体大小来适配，否侧就不设置
            if (designSize <= 750) {
                const remSize = (w / designSize) * 100;
                html.style.fontSize = `${remSize}px`;
            } else {
                html.style.fontSize = '';
            }
        }
       
        

    }

    initResize();

    window.addEventListener('resize', initResize, false);
  
};

export const initRootRemSizeNew = ({ cab }) => {
    function initResize() {
        let designSize = 1920;
        const html = document.documentElement;
       
        let cw = html.getBoundingClientRect().width;
        if (cw <= 750) {
            designSize = 750;
        }

        if (cw > 750 && cw <= 1440) {
            designSize = 1440;
        }

        if (cw > 1440 && cw <= 2560) {
            // designSize = 2560;
            designSize = cw;
        }

        const w = cw;

        // 如果小于或者等于 750 的设计图，就设置根元素字体大小来适配，否侧就不设置
        if (designSize <= 750) {
            const remSize = (w / designSize) * 100;
            html.style.fontSize = `${remSize}px`;
            cab(w);
        } else {
            html.style.fontSize = '';
        }
        cab(w);
    }

    initResize();

    window.addEventListener('resize', initResize, false);
  
};


const getScrollTop = ({callback}) => {
    const scrollTopVal = document.documentElement.scrollTop;
    const cHSTopVal = scrollTopVal + document.documentElement.clientHeight;
    let scrollVal;
    if (scrollTopVal <= 20) {
        scrollVal = 0;
    } else {
        scrollVal = scrollTopVal;
    }
    callback({scrollVal, cHSTopVal});
}

//获取文档内容的的高度
export const handleScroll = ({cab}) => {
    window.addEventListener('scroll', () => {
        getScrollTop({
            callback: ({scrollVal, cHSTopVal}) => {
                cab({scrollVal, cHSTopVal});
            }
        });
    }, false);
}


// 回到顶部
export const backTo = () => {
    const val = storage('scrollTopKey').getStorage();
    document.documentElement.scrollTop = val ? val : 0;
}

export const getBackTo = () => {
    document.documentElement.scrollTop = 0;
}


export const getOffset = (curEle) => {
    let par = curEle.offsetParent, // 获取父级参照物
        l = curEle.offsetLeft, // 获取左边距离我的参照物的距离
        t = curEle.offsetTop; // 获取上边距离我的参照物的距离

    // 循环
    while (par && par.tagName !== 'BODY') {
        if (!/MSIE 8\./.test(navigator.userAgent)) {
            l += par.clientWidth;
            t += par.clientHeight;
        }
        l += par.offsetLeft;
        t += par.offsetTop;
        par = par.offsetParent;
    }

    return {
        top: t,
        left: l,
    }

};

export const getParentElement = (parentEle) => {
    return parentEle;
};


export const getClientRect = (curEle, innerNum=100) => {
    let { bottom, height, left, right, top, width, x, y } = curEle.current.getBoundingClientRect(); // 当前元素

    

    const isClientRect = top >= 0 && bottom > window.innerHeight + innerNum;

    return {
        isClientRect,
        parms: {
            bottom, height, left, right, top, width, x, y
        }
     };
};

export const getModelClientRect = (curEle, innerNum=0) => {

    const docModel = document.documentElement.querySelector(".drawerBody");

    

    if(docModel){
        let { bottom, height, left, right, top, width, x, y } = curEle.current.getBoundingClientRect(); // 当前元素
        const isClientRect = top >= 0 && bottom > (docModel.clientHeight + innerNum);
        return {
            isClientRect,
            parms: {
                bottom, height, left, right, top, width, x, y
            }
         };
    }
};





export const delay = (ms, callback) => {
    setTimeout(() => {
        callback();
    }, ms);
};


export const isScreenHeight = window.screen.height - window.screen.availHeight;

//是移动端返回true,否则false
export const isMobile = () => {
    return (/phone|pad|pod|iPhone|iPod|ios|iPad|Android|Mobile|BlackBerry|IEMobile|MQQBrowser|JUC|Fennec|wOSBrowser|BrowserNG|WebOS|Symbian|Windows Phone|webOS|android/i.test(navigator.userAgent))
};

export const storage = (key, val) => {
    return {
        setStorage: () => sessionStorage.setItem(key, JSON.stringify(val)),
        getStorage: () => JSON.parse(sessionStorage.getItem(key)),
        removeStorage: () => sessionStorage.removeItem(key),
    }
}


let innerAnimateScrollList = {};
export const getInnerAnimateScrollList = (args) => {
    innerAnimateScrollList = args;
};

export const handleHeadNavLinkJump = (callback) => {
    callback(innerAnimateScrollList);
};


export const isMath = (reSize, num) => {
    return reSize <= 750 ? `${num / 100}rem` : `${num}px`;
}

// 创建事件回调
let initFunc = null;
export const changeDispatchEvent = () => {
    if(Object.prototype.toString.call(initFunc) === `[object Function]`){
        initFunc();
    }
}
export const changeDispatchInner = (callback) => {
    initFunc = callback
}


// 事件触发
/**
 *
 * @param currentEle    元素
 * @param eventMethod   事件方法
 * @param data          数据
 * @param callback      事件回调
 */
export const eventRun = ({currentEle, eventMethod, data, callback}) => {
    const event = new EventEmitter();
    const videoMessage = (msg) => {
        callback({
            ele: currentEle, // 元素
            message: msg,    // 消息
        });
    };
    event.on(eventMethod, videoMessage);
    event.emit(eventMethod, data ? data : {});
}

// 发送邮箱 📪
export const mailtoSubmit = ({eMailAddress}) => {
    const who = prompt('请输入收件人邮箱: ', eMailAddress);
    const what = prompt('输入主题: ', 'Note');
    if (window.confirm(`你确定要向 ${who} 发送主题为 ${what} 的邮件么?`) === true) {
        window.parent.location.href = `mailto: ${who}?subject=${what} `;
    }
}

// 判断是中文还是英文，对样式的处理
export const isNormalZhEnCss = (lang, type) => lang === type;

export const setModuleWidthSize = (initFontSize) => {
    let val;
    if (initFontSize > 1920) {
      val = '1340px';
    } else if (initFontSize > 1440 && initFontSize <= 1920) {
      val = '1330px';
    } else if (initFontSize > 1024 && initFontSize <= 1440) {
      val = '1200px';
    } else if (initFontSize > 750 && initFontSize <= 1024) {
      val = '823px';
    }
    return val;
};



// JS处理iOS等设备控件挡住页面内容的问题
export const getOuterHeight= () => {
    if (navigator.userAgent.match(/iPhone/i) || navigator.userAgent.match(/iPad/i)) {//判断设备类型
        let heroHeight =  window.innerHeight;//获取窗口可视高度
        return heroHeight;
    }
}

 //  获取指定指定时区时间（北京时区为8，纽约时区为-5。东时区为正数，西市区为负数）
 export const getSystemTime = (date) => {
     const timezone = 8;
    // 本地时间距离（GMT时间）毫秒数
    let nowDate = !date ? new Date().getTime() : new Date(date).getTime()
    // 本地时间和格林威治时间差，单位分钟
    let offset_GMT = new Date().getTimezoneOffset()
    //  反推到格林尼治时间
    let GMT = nowDate + offset_GMT * 60 * 1000 
    //  获取指定时区时间
    let targetDate = new Date(GMT + timezone * 60 * 60 * 1000);
    return targetDate
}







